/*
 * Distributed under the Berkeley 4-part license
 */


#define SPLITRAW_DEFAULT_EXTENSION "000"

extern struct af_vnode vnode_split_raw;


