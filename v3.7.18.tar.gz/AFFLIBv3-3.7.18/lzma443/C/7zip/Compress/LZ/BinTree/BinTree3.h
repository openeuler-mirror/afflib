// BinTree3.h

#ifndef __BINTREE3_H
#define __BINTREE3_H

#define BT_NAMESPACE NBT3

#define HASH_ARRAY_2

#include "BinTreeMain.h"

#undef HASH_ARRAY_2

#undef BT_NAMESPACE

#endif
