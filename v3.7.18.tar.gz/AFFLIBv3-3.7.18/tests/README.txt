This directory contains some additional tests which can be run to validate the AFF distribution.

The file encrypted.aff is a standardized encrypted file that is
encrypted with the passphrase 'password'.

NOTE: Remember to set the svn:executable property on all of the shell scripts so that
 they get checked out with the execute bit set
